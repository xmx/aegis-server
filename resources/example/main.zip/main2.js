import * as math from "hello/math";

export function hello() {
    console.log("A+B=", math.add(23, 45))
}
