import * as os from "os";
import * as math from "hello/math";
import * as main2 from "main2";


console.log("进程PID：", os.getpid());

console.log("456+789=", math.add(456, 789));

main2.hello()